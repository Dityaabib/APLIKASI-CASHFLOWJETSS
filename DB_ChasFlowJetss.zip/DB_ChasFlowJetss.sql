-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 8.4.3 - MySQL Community Server - GPL
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- membuang struktur untuk table cashflow.cache
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.cache: ~5 rows (lebih kurang)
INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
	('laravel-cache-user-is-online-28', 'b:1;', 1768553798),
	('laravel-cache-user-is-online-32', 'b:1;', 1768714378),
	('laravel-cache-user-is-online-33', 'b:1;', 1768372288);

-- membuang struktur untuk table cashflow.cache_locks
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.cache_locks: ~0 rows (lebih kurang)

-- membuang struktur untuk table cashflow.expense_budgets
CREATE TABLE IF NOT EXISTS `expense_budgets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_amount` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expense_budgets_user_id_label_unique` (`user_id`,`label`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.expense_budgets: ~6 rows (lebih kurang)
INSERT INTO `expense_budgets` (`id`, `user_id`, `label`, `max_amount`, `created_at`, `updated_at`) VALUES
	(8, 27, 'Transportasi', 500000, '2026-01-01 20:37:03', '2026-01-01 20:37:03'),
	(10, 27, 'Utang', 1000000, '2026-01-04 21:28:25', '2026-01-04 21:28:25'),
	(12, 27, 'Belanja', 600000, '2026-01-05 00:29:25', '2026-01-12 01:04:19'),
	(13, 27, 'SPP', 1000000, '2026-01-16 00:04:45', '2026-01-16 00:04:45'),
	(14, 28, 'Transportasi', 200000, '2026-01-16 00:36:19', '2026-01-16 00:36:19'),
	(15, 28, 'Belanja', 500000, '2026-01-16 00:36:25', '2026-01-16 00:36:25'),
	(16, 27, 'Hiburan', 500000, '2026-01-17 21:32:26', '2026-01-17 21:32:26'),
	(17, 40, 'Tagihan', 1000000, '2026-01-17 21:56:11', '2026-01-17 21:56:11'),
	(18, 40, 'Transportasi', 500000, '2026-01-17 21:56:22', '2026-01-17 21:56:22'),
	(19, 40, 'Belanja', 1000000, '2026-01-17 21:56:33', '2026-01-17 21:56:33'),
	(20, 40, 'Makanan', 200000, '2026-01-17 21:56:45', '2026-01-17 21:56:45');

-- membuang struktur untuk table cashflow.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.failed_jobs: ~0 rows (lebih kurang)

-- membuang struktur untuk table cashflow.jobs
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.jobs: ~0 rows (lebih kurang)

-- membuang struktur untuk table cashflow.job_batches
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.job_batches: ~0 rows (lebih kurang)

-- membuang struktur untuk table cashflow.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.migrations: ~0 rows (lebih kurang)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '0001_01_01_000000_create_users_table', 1),
	(2, '0001_01_01_000001_create_cache_table', 1),
	(3, '0001_01_01_000002_create_jobs_table', 1),
	(4, '2025_11_24_000100_add_username_to_users_table', 1),
	(5, '2025_11_27_000000_create_transactions_table', 2),
	(6, '2025_12_01_000001_create_expense_budgets_table', 3),
	(7, '2026_01_02_054031_add_avatar_to_users_table', 4),
	(8, '2026_01_12_050545_add_leveled_to_users_table', 5),
	(9, '2026_01_13_050713_add_last_seen_to_users_table', 6);

-- membuang struktur untuk table cashflow.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.password_reset_tokens: ~0 rows (lebih kurang)

-- membuang struktur untuk table cashflow.sessions
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.sessions: ~1 rows (lebih kurang)
INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
	('1Eo62FneencjnbfD5e8mejS8jDmH6spejtSVchRG', 39, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSmdMdm00NnRla1dGNGttbTBVYzdIcDE5d3hpdHpYWFpjcUpEcmhXciI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM4OiJodHRwOi8vMTkyLjE2OC4wLjQ6MTEyMi9hZG1pbi9zZXR0aW5ncyI7czo1OiJyb3V0ZSI7czoxNDoiYWRtaW4uc2V0dGluZ3MiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozOTt9', 1768713570),
	('3SZakyRBu2ekuUOKUQDgjOKMvTEincqlxefQ7dTs', NULL, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSzdzRmZhalU3c1UwRGdFUlNTWjNaN255UU40MDJSNnZ3UTVucHdFVyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNToiaHR0cDovLzE5Mi4xNjguMC40OjExMjIvYWRtaW4vdXNlcnMiO31zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyOToiaHR0cDovLzE5Mi4xNjguMC40OjExMjIvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1768713365),
	('Mb6hAi5BurfZTkpHZIG9yhqlNz6DuYMqksyPoSDO', NULL, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTZWTDdjd1JvTlNWbGJaalR1TTJVQkJLaldNb3B4eE5YOGVmRjhvbiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xOTIuMTY4LjAuNDoxMTIyL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9fQ==', 1768712549),
	('nEjhWkB7YXR2oIRVUOs7w8rH21ztud5WEybVkAoj', 32, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQ2hSTHRzWUVLblVtMzJaSHVFVFpqcUFQeDBCN2F0Qm8yQUQ5UEV3dSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly8xOTIuMTY4LjAuNDoxMTIyL2FkbWluL3NldHRpbmdzIjtzOjU6InJvdXRlIjtzOjE0OiJhZG1pbi5zZXR0aW5ncyI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjMyO30=', 1768712428),
	('sY9ha5jPVQf1UqFOkKcTUVgBqQWKJfMRvf5D1BNc', 32, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidzJMMHBHZDZSUWV6b1E3czRDTnI5eWxXSzE4RHdzb2lnbUljWktENiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly8xOTIuMTY4LjAuNDoxMTIyL2FkbWluL3NldHRpbmdzIjtzOjU6InJvdXRlIjtzOjE0OiJhZG1pbi5zZXR0aW5ncyI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjMyO30=', 1768714078),
	('uFOjmPHo399nnRKX9bAJjR6dvsemFnXhqIb4aZT3', NULL, '192.168.0.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkc1Q1ZxUThSSWkyUjhlVjFRVEF1U09NNEk0eHREWEJYdzBvRDNOVCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xOTIuMTY4LjAuNDoxMTIyL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9fQ==', 1768713822);

-- membuang struktur untuk table cashflow.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` enum('income','expense') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_user_id_foreign` (`user_id`),
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.transactions: ~21 rows (lebih kurang)
INSERT INTO `transactions` (`id`, `user_id`, `type`, `amount`, `category`, `date`, `description`, `created_at`, `updated_at`) VALUES
	(101, 27, 'income', 1000000.00, 'Lainnya', '2026-01-02', 'SPP SEKOLAH', '2026-01-01 20:35:16', '2026-01-05 00:32:58'),
	(102, 27, 'expense', 250000.00, 'Transportasi', '2026-01-02', 'BENERIN SEPEDA MOTOR', '2026-01-01 20:36:00', '2026-01-01 20:36:00'),
	(104, 27, 'expense', 120000.00, 'Utang', '2026-01-05', 'Bayar shopee', '2026-01-04 21:23:58', '2026-01-04 21:23:58'),
	(107, 27, 'income', 150000.00, 'Bonus', '2026-01-05', 'dari ayah', '2026-01-04 21:30:00', '2026-01-05 00:22:11'),
	(108, 27, 'expense', 100000.00, 'Belanja', '2026-01-04', NULL, '2026-01-05 00:29:03', '2026-01-05 00:29:03'),
	(112, 27, 'expense', 30000.00, 'Transportasi', '2026-01-12', NULL, '2026-01-11 21:44:47', '2026-01-11 21:44:47'),
	(114, 27, 'expense', 400000.00, 'Belanja', '2026-01-08', 'opsi', '2026-01-12 01:03:49', '2026-01-12 01:03:49'),
	(118, 27, 'expense', 100000.00, 'SPP', '2026-01-16', NULL, '2026-01-16 00:04:13', '2026-01-16 00:04:13'),
	(119, 28, 'income', 100000.00, 'Hadiah', '2026-01-16', NULL, '2026-01-16 00:36:01', '2026-01-16 00:36:01'),
	(120, 28, 'income', 500000.00, 'Gaji', '2026-01-16', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(121, 28, 'expense', 200000.00, 'Transportasi', '2026-01-16', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(122, 28, 'income', 100000.00, 'Bonus', '2026-01-14', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(123, 28, 'expense', 50000.00, 'Transportasi', '2026-01-15', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(124, 28, 'expense', 200000.00, 'Belanja', '2026-01-16', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(125, 28, 'expense', 10000.00, 'Belanja', '2026-01-15', NULL, '2026-01-16 00:36:02', '2026-01-16 00:36:02'),
	(126, 28, 'income', 2000000.00, 'Gaji', '2026-01-15', NULL, '2026-01-16 00:53:35', '2026-01-16 00:53:35'),
	(127, 27, 'income', 50000.00, 'Bonus', '2026-01-15', NULL, '2026-01-16 01:32:31', '2026-01-16 01:32:31'),
	(128, 27, 'expense', 10000.00, 'Transportasi', '2026-01-16', NULL, '2026-01-16 01:46:19', '2026-01-16 01:46:19'),
	(129, 27, 'expense', 10000.00, 'Belanja', '2026-01-16', NULL, '2026-01-16 01:47:26', '2026-01-16 01:47:26'),
	(130, 27, 'expense', 100000.00, 'Hiburan', '2026-01-18', NULL, '2026-01-17 21:30:13', '2026-01-17 21:30:13'),
	(131, 27, 'income', 50000.00, 'Hadiah', '2026-01-18', NULL, '2026-01-17 21:30:13', '2026-01-17 21:30:13'),
	(132, 40, 'income', 3000000.00, 'Gaji', '2026-01-02', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(133, 40, 'expense', 250000.00, 'Transportasi', '2026-01-05', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(134, 40, 'expense', 10000.00, 'Makanan', '2026-01-03', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(135, 40, 'expense', 20000.00, 'Belanja', '2026-01-08', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(136, 40, 'expense', 200000.00, 'Belanja', '2026-01-05', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(137, 40, 'income', 50000.00, 'Bonus', '2026-01-09', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36'),
	(138, 40, 'expense', 500000.00, 'Tagihan', '2026-01-18', NULL, '2026-01-17 21:55:36', '2026-01-17 21:55:36');

-- membuang struktur untuk table cashflow.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` enum('user','administrator') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel cashflow.users: ~10 rows (lebih kurang)
INSERT INTO `users` (`id`, `name`, `email`, `avatar`, `username`, `level`, `email_verified_at`, `password`, `last_seen`, `created_at`, `updated_at`) VALUES
	(27, 'Aditya wahyu habbibulloh', 'aditya.wahyu8518@smk.belajar.id', '1768547948.jpg', 'aditya', 'user', NULL, '$2y$12$tLem0mRqcUNj3WSadoJM7OSY6dRkMC2oJVSnGMw1upqzpJBy6a47C', NULL, '2025-11-28 19:35:07', '2026-01-17 22:23:36'),
	(28, 'ezar firmansa nigrat', 'Tegar@gmail.com', '1768552441.jpg', 'ezar', 'user', NULL, '$2y$12$xLMbHAWQhoXf1DJju7WB5uCbFaRWNlpu1MQgkS.IJTVR1Fg5.tKeu', '2026-01-16 01:51:38', '2026-01-03 06:13:03', '2026-01-16 01:51:38'),
	(32, 'AdministratorUtama', 'adminUtama@gamil.com', NULL, 'admin', 'administrator', NULL, '$2y$12$tLem0mRqcUNj3WSadoJM7OSY6dRkMC2oJVSnGMw1upqzpJBy6a47C', '2026-01-17 22:27:58', NULL, '2026-01-17 22:27:58'),
	(33, 'Andi susanto', 'kontol10@gmail.com', '1768371734.jpg', 'Kontol kejepit ahh', 'user', NULL, '', '2026-01-13 23:26:28', '2026-01-13 23:17:19', '2026-01-13 23:26:28'),
	(34, 'testsatudua tiga di coba dalam melakukan ', 'aditya@gmail.com', NULL, 'test', 'user', NULL, '$2y$12$xLMbHAWQhoXf1DJju7WB5uCbFaRWNlpu1MQgkS.IJTVR1Fg5.tKeu', NULL, NULL, NULL),
	(35, 'ahahahahahahah', 'testahahahah12@gmail.com', NULL, 's', 'user', NULL, '$2y$12$xLMbHAWQhoXf1DJju7WB5uCbFaRWNlpu1MQgkS.IJTVR1Fg5.tKeu', NULL, NULL, NULL),
	(36, 'mas bosss senteruu', 'boobs@gmail.com', NULL, 'adminbob', 'administrator', NULL, '$2y$12$qVEbz84JclBHqNzjVzOPi.1qBLGntOeEd5J3HER4E0/EDkO/CrZwS', NULL, '2026-01-14 22:47:22', '2026-01-15 00:44:44'),
	(37, 'meyangkara junaidi', 'junaidiwahyu@gmail.com', NULL, 'adityaWahy', 'administrator', NULL, '$2y$12$WgIVvX4.vYIG4r9ZI23b4OmJlAeKEfWS/HiT.JP6iqKPi9nek8e/G', NULL, '2026-01-14 22:58:38', '2026-01-15 00:56:26'),
	(38, 'tegar dudi santoso nigrat', 'dtegar@gamil.com', NULL, 'dtegarnigrat', 'administrator', NULL, '$2y$12$DNareBDldNLpjparrTistetopbtbp2Zz06ECQobJH4OOxFRmrr2V.', NULL, '2026-01-14 23:02:19', '2026-01-17 22:02:28'),
	(39, 'tegarAdminBarusatu', 'dtega@gamil.com', NULL, 'tegar', 'administrator', NULL, '$2y$12$/JnkyOoZ19xH6Ow5YX9oEO154VXtK2MPX5jKlGfaYbGJPn49ml9Zi', NULL, '2026-01-15 19:34:51', '2026-01-17 22:23:42'),
	(40, 'Muahmmad mutfi', 'mutfi@gmail.com', NULL, 'mutfi', 'user', NULL, '$2y$12$dJMBjyuvm.ISh7Rg2gjg7eWihZ.fCKc5JGmL5afmPLzzpUZWMyf.e', NULL, '2026-01-17 21:46:56', '2026-01-17 21:57:29');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
